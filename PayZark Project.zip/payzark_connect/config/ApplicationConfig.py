import os
from dataclasses import dataclass


@dataclass
class ApplicationConfig(object):
    FLASK_APP_BASE_URL: str = "http://0.0.0.0:5000"
    FLASK_APP_SECRET_KEY: str = os.environ.get("FLASK_APP_SECRET_KEY")
    DATABASE_URI: str = os.environ.get("DATABASE_URI")
    PHONE_OTP_EXPIRATION_SECONDS: int = int(
        os.environ.get("PHONE_OTP_EXPIRATION_SECONDS")
    )
    PHONE_OTP_RESEND_ELIGIBLE_SECONDS: int = int(
        os.environ.get("PHONE_OTP_RESEND_ELIGIBLE_SECONDS")
    )
    PHONE_OTP_MAX_RESEND_ATTEMPTS: int = int(
        os.environ.get("PHONE_OTP_MAX_RESEND_ATTEMPTS")
    )
