from flask import request, jsonify
from flask.blueprints import Blueprint

from payzark_connect.handlers.RegistrationHandler import RegistrationHandler

blueprint = Blueprint("identification", __name__)


@blueprint.before_request
def validate_tenant_id_on_every_request():
    if not request.headers.get("TENANT-ID"):
        return jsonify({
            "error": True,
            "message": f"Registration request should have a tenant id"
        }), 400
    if not request.headers.get("auth_token"):
        return jsonify({
            "error": True,
            "message": f"Registration request should have a tenant id"
        }), 403


@blueprint.route("/stats", methods=["GET"])
def get_stats():
    return RegistrationHandler(request.json, request.headers.get("TENANT-ID")).handle()
