from flask.blueprints import Blueprint
from payzark_connect.models import Pancard 
blueprint = Blueprint("index", __name__)


@blueprint.before_request
def intercept():
    print("Index before")


@blueprint.route("/")
def index():
    return "Admin OK"
