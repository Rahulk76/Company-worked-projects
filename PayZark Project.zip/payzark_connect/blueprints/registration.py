from flask import request, jsonify
from flask.blueprints import Blueprint
from payzark_connect.models import Aadharcard

from payzark_connect.handlers.RegistrationHandler import RegistrationHandler
from ..handlers.RegistrationOtpResendHandler import RegistrationOtpResendHandler
from ..handlers.RegistrationOtpVerificationHandler import RegistrationOtpVerificationHandler

blueprint = Blueprint("registration", __name__)


@blueprint.before_request
def validate_tenant_id_on_every_request():
    if not request.headers.get("TENANT-ID"):
        return jsonify({
            "error": True,
            "message": f"Registration request should have a tenant id"
        }), 400


@blueprint.route("/", methods=["POST"])
def register():
    return RegistrationHandler(request.json, request.headers.get("TENANT-ID")).handle()


@blueprint.route("/resend-otp", methods=["POST"])
def resend_otp():
    return RegistrationOtpResendHandler(request.json).handle()


@blueprint.route("/verify-otp", methods=["POST"])
def verify():
    return RegistrationOtpVerificationHandler(request.json).handle()
