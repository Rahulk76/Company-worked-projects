from flask import request, jsonify, json
from flask.blueprints import Blueprint
# import requests

from ..handlers.Personaldetailshandlers import PersonalDetailsHandler
from ..models.Personaldetailsmodels import Personaldetailsmodels



blueprint = Blueprint("personaldetails", __name__)


@blueprint.before_request
def validate_tenant_id_on_every_request():
    if not request.headers.get("TENANT-ID"):
        return jsonify(
            {"error": True,
             "message": f"Registration request should have a tenant id"}
        )


@blueprint.route("/", methods=["GET"])
def get():
    account = Personaldetailsmodels.query.all()

    return jsonify(account)


@blueprint.route("/get/<int:acc_id>", methods=["GET"])
def get_singledetail(acc_id):
    account = Personaldetailsmodels.query.get(acc_id)

    return jsonify(account)


@blueprint.route("/create", methods=["POST"])
def create():
    return PersonalDetailsHandler(request.json).handle()


@blueprint.route("/update/<int:acc_id>", methods=["PUT"])
def updateaccountdata(acc_id):
    return PersonalDetailsHandler(request.json).update_account(acc_id)



