from flask import request, jsonify
from flask.blueprints import Blueprint

from payzark_connect.models.AccountDetailsModel import AccountDetailsModel


from ..handlers.Accountdetailshandlers import Accountdetailshandler


blueprint = Blueprint("agentregistration", __name__)


@blueprint.before_request
def validate_tenant_id_on_every_request():                                                       
    if not request.headers.get("TENANT-ID"): 
        return jsonify({
            "error": True,
            "message": f"Registration request should have a tenant id"
        }),400


# @blueprint.route("/get", methods=["GET"])
# def getdata():
#     account = AccountDetailsModel.query.filter()
#     data = []
#     for i in account:
#         data.append(i)
#     return jsonify(data[0])
 
# @blueprint.route("/get", methods=["GET"])
# def get():
#     return Accountdetailshandler(request.json,request.headers.get("TENANT-ID")).handle()

@blueprint.route("/", methods=["POST"])
def create():
    return Accountdetailshandler(request.json).handle()


# @blueprint.route("/update", methods=["PUT"])
# def update():
#     return Accountdetailshandler(request.json).handle()
 

@blueprint.route("/update/<int:account_id>", methods=["PUT"])
def updateaccountdata(account_id):
    return Accountdetailshandler(request.json).updateaccount(account_id) 


@blueprint.route("/get/<int:account>", methods=["GET"])
def getsingledata(account):
     account1 = AccountDetailsModel.query.get(account)

     return jsonify(account1) 



     