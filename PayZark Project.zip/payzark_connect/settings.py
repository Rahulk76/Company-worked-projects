import os

from flask import Flask

from payzark_connect.config.ApplicationConfig import ApplicationConfig


def database_uri():
    return ApplicationConfig.DATABASE_URI


def init_app(app: Flask):
    app.secret_key = ApplicationConfig.FLASK_APP_SECRET_KEY or os.urandom(24)
    print(database_uri())
    app.config.update(
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        SQLALCHEMY_DATABASE_URI=database_uri(),
        BASE_URL=ApplicationConfig.FLASK_APP_BASE_URL,
    )



