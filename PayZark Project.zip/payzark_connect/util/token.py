import base64
import hashlib
import json
from dataclasses import dataclass, asdict

from payzark_connect.models.PartnerModel import PartnerRole


@dataclass
class PartnerInfo:
    partner_id: int
    role: PartnerRole
    payzark_tenant_id: int


def generate_token(partner_info: PartnerInfo):
    partner = base64.b64encode(json.dumps(asdict(partner_info)).encode("utf-8"))
    return f"{hashlib.md5(partner).hexdigest()}.{partner.decode('utf-8')}"


def verify_token(token: str) -> PartnerInfo:
    partner_hash, partner_info_str = token.split(".")
    partner_info = json.loads(base64.decodebytes(partner_info_str.encode("utf-8")).decode("utf-8"))
    if generate_token(partner_info).split(".")[0] != partner_hash:
        raise Exception("Not valid token")

    return partner_info
