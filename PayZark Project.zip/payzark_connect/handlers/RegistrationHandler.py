from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict

from flask import jsonify

from payzark_connect.models.OtpVerificationModel import (
    OtpVerificationModel,
    OtpVerificationStatus,
)
from payzark_connect.util.otp import generate_otp
from .. import db
from ..config.ApplicationConfig import ApplicationConfig
from ..models.PartnerModel import PartnerAccountStatus, PartnerModel, PartnerRole


@dataclass
class RegistrationRequestBody:
    firstName: str
    lastName: str
    postalCode: int
    phoneNumberCountryCode: str
    phoneNumber: str
    ipAddress: str


    def __init__(self, request_dict: Dict):
        for k, v in request_dict.items():
            setattr(self, k, v)


class RegistrationHandler:
    request: RegistrationRequestBody
    tenant_id: int

    def __init__(self, request: Dict, tenant_id: int):
        self.request = RegistrationRequestBody(request)
        self.tenant_id = tenant_id

    def handle(self):
        existing_partner_candidate = self.__get_existing_partner_candidate()

        if existing_partner_candidate:
            if existing_partner_candidate.registration_verification.status == OtpVerificationStatus.VERIFIED:
                return jsonify({
                    "error": True,
                    "message": f"Partner exists"
                }), 409
            else:
                partner = self._update_existing_unverified_partner(existing_partner_candidate)
        else:
            partner = self.__create_new_partner()

        return jsonify({
            "partnerId": partner.id
        }), 201

    def __get_existing_partner_candidate(self) -> PartnerModel | None:
        result = PartnerModel.query.filter(
            PartnerModel.phone_country_code == self.request.phoneNumberCountryCode,
            PartnerModel.phone_number == self.request.phoneNumber,
            PartnerModel.payzark_tenant_id == self.tenant_id,
        )
        if result.count() == 0:
            return None

        return result[0]

    def __create_new_partner(self):
        partner = PartnerModel(
            first_name=self.request.firstName,
            last_name=self.request.lastName,
            postal_code=self.request.postalCode,
            phone_country_code=self.request.phoneNumberCountryCode,
            phone_number=self.request.phoneNumber,
            status=PartnerAccountStatus.CREATED,
            role=PartnerRole.DEFAULT,
            payzark_tenant_id=self.tenant_id,
            registration_verification=self._get_new_registration_verification_object(),
            update_count=0,
        )

        with db.transaction():
            db.persist(partner)

        return partner

    def _update_existing_unverified_partner(self, existing_partner: PartnerModel) -> PartnerModel:
        existing_partner.first_name = self.request.firstName
        existing_partner.last_name = self.request.lastName
        existing_partner.postal_code = self.request.postalCode
        existing_partner.phone_country_code = self.request.phoneNumberCountryCode
        existing_partner.phone_number = self.request.phoneNumber
        existing_partner.status = PartnerAccountStatus.CREATED
        existing_partner.payzark_tenant_id = self.tenant_id

        if existing_partner.registration_verification.ip_address != self.request.ipAddress:
            """A different IP address could mean that a different partner is trying with same phone number.
            Possibly a fraud, so we refresh the data to give opportunity to this new partner to verify and register.
            """
            existing_partner.registration_verification = self._get_new_registration_verification_object()
        else:
            """For existing partners, update the general info and maintain same verification data to prevent fraud"""
            pass

        with db.transaction():
            db.persist(existing_partner)

        return existing_partner

    def _get_new_registration_verification_object(self) -> OtpVerificationModel:
        return OtpVerificationModel(
            otp=generate_otp(),
            otp_expire_at=datetime.utcnow() + timedelta(0, ApplicationConfig.PHONE_OTP_EXPIRATION_SECONDS),
            otp_resend_eligible_at=datetime.utcnow() + timedelta(0,
                                                                 ApplicationConfig.PHONE_OTP_RESEND_ELIGIBLE_SECONDS),
            status=OtpVerificationStatus.UNVERIFIED,
            resend_attempts=0,
            ip_address=self.request.ipAddress
        )
