from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict

from flask import jsonify

from payzark_connect.models.OtpVerificationModel import (
    OtpVerificationStatus,
)
from payzark_connect.util.otp import generate_otp
from .. import db
from ..config.ApplicationConfig import ApplicationConfig
from ..models.PartnerModel import PartnerModel


@dataclass
class RegistrationOtpResendRequestBody:
    partnerId: int

    def __init__(self, request_dict: Dict):
        for k, v in request_dict.items():
            setattr(self, k, v)


class RegistrationOtpResendHandler:
    request: RegistrationOtpResendRequestBody

    def __init__(self, request: Dict):
        self.request = RegistrationOtpResendRequestBody(request)

    def handle(self):
        existing_partner_candidate = self.__get_partner_candidate()
        if not existing_partner_candidate:
            return jsonify({
                "error": True,
                "message": f"Partner {self.request.partnerId} does not exist for"
            }), 404
        elif existing_partner_candidate.registration_verification.status == OtpVerificationStatus.VERIFIED:
            return jsonify({
                "error": True,
                "message": f"Partner {self.request.partnerId} already verified"
            }), 403
        elif (
                existing_partner_candidate.registration_verification.resend_attempts + 1
                > ApplicationConfig.PHONE_OTP_MAX_RESEND_ATTEMPTS
        ):
            return jsonify({
                "error": True,
                "message": f"Partner {self.request.partnerId} exceeded retry attempts"
            }), 403

        if existing_partner_candidate.registration_verification.otp_expire_at < datetime.utcnow():
            existing_partner_candidate.registration_verification.otp = generate_otp()
            existing_partner_candidate.registration_verification.otp_expire_at \
                = datetime.utcnow() + timedelta(0,
                                                ApplicationConfig.PHONE_OTP_EXPIRATION_SECONDS)
        elif existing_partner_candidate.registration_verification.otp_resend_eligible_at > datetime.utcnow():
            existing_partner_candidate.registration_verification.resend_attempts \
                = existing_partner_candidate.registration_verification.resend_attempts + 1
            existing_partner_candidate.registration_verification.otp_resend_eligible_at \
                = datetime.utcnow() + timedelta(0,
                                                ApplicationConfig.PHONE_OTP_RESEND_ELIGIBLE_SECONDS)
            with db.transaction():
                db.persist(existing_partner_candidate)

        return jsonify({
            "resend_eligible_at": existing_partner_candidate.registration_verification.otp_resend_eligible_at
        }), 201

    def __get_partner_candidate(self) -> PartnerModel | None:
        result = PartnerModel.query.filter(
            PartnerModel.id == self.request.partnerId,
        )
        if result.count() == 0:
            return None

        return result[0]
