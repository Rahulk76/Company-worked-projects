from dataclasses import dataclass
from datetime import datetime
from typing import Dict
from .. import db
from flask import jsonify
from ..models.AccountDetailsModel import AccountDetailsModel,AccountType


@dataclass
class AccountDetailsBody:

    distributor_name: str
    bankname: str
    accountnumber: int 
    ifsccode: str
    bankpassbook: str
    typeofaccount: AccountType
    cancelledcheque: str
    # createdat: datetime
    # updatedat: datetime
    # updatecount: int

    def __init__(
        self,
        request_dict: Dict,
    ):
        for key, value in request_dict.items():
            setattr(self, key, value)


class Accountdetailshandler:
    request: AccountDetailsBody
    tenant_id: int

    def __init__(self, request: Dict):
        self.request = AccountDetailsBody(request)

    def handle(self):
        existing_account_details = self.__get_existing_account_details()
    

        if existing_account_details:

            return jsonify({"error": True, "message": f"Account Details Already Exists"})

        else:
            account_id = self.__create_new_account_details()

        return jsonify({"Account_Details_Uploaded_Successfully"})

    def __get_existing_account_details(self) -> AccountDetailsModel | None:
        result = AccountDetailsModel.query.filter(
            AccountDetailsModel.account_number == self.request.accountnumber,   
        )
        if result.count() == 0:
            return None

        return result[0]

    def __create_new_account_details(self):
        account_details = AccountDetailsModel(
            distributor_name=self.request.distributor_name,
            bank_name=self.request.bankname,
            account_number=self.request.accountnumber,
            ifsc_code=self.request.ifsccode,
            bank_passbook=self.request.bankpassbook,
            type_of_account=self.request.typeofaccount,
            cancelled_cheque=self.request.cancelledcheque,
            # payzark_tenant_id=self.tenant_id,
            # update_count=0,
        )

        with db.transaction():
            db.persist(account_details)

        return account_details

    def updateaccount(self, account_id):

            accountdata = AccountDetailsModel.query.get(account_id)

            accountdata.distributor_name = self.request.distributor_name
            accountdata.bank_name = self.request.bankname
            # accountdata.account_account_number = self.request.accountnumber
            accountdata.ifsc_code = self.request.ifsccode
            accountdata.bank_passbook = self.request.bankpassbook
            accountdata.type_of_account = self.request.typeofaccount
            accountdata.cancelled_cheque = self.request.cancelledcheque

            with db.transaction():
                db.persist(accountdata)

            return {"Status": "Account updated successfully"}
