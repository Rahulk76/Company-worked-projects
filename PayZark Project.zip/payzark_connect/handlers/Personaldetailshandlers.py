from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict
from .. import db
# import requests, json
from flask import jsonify, request
from ..models.Personaldetailsmodels import Personaldetailsmodels




@dataclass
class PersonalDetailsRequestBody:

    FirstName: str
    LastName: str
    PhoneNumber: int
    ZipCode: int
    State: str
    City: str
    Address: str

    def __init__(self, request_dict: Dict):
        for k, v in request_dict.items():
            setattr(self, k, v)


class PersonalDetailsHandler:
    request: PersonalDetailsRequestBody

    def __init__(self, request: Dict):
        self.request = PersonalDetailsRequestBody(request)

    def handle(self):
        existing_personal_details = self.__get_personal_account_details()

        if existing_personal_details:

            return jsonify({
                    "error": True,
                    "message": f"PERSONAL_DETAILS_ALREADY_EXISTS"
                })

        else:
            personal_id = self.__create_new_personal_details()

        return personal_id

    def __get_personal_account_details(self) -> Personaldetailsmodels | None:
        result = Personaldetailsmodels.query.filter(
            Personaldetailsmodels.PhoneNumber == self.request.PhoneNumber,
            Personaldetailsmodels.ZipCode == self.request.ZipCode,
        )
        if result.count() == 0:
            return None

        return result[0]

    def __create_new_personal_details(self):
        personal_details = Personaldetailsmodels(
            FirstName=self.request.FirstName,
            LastName=self.request.LastName,
            PhoneNumber=self.request.PhoneNumber,
            ZipCode=self.request.ZipCode,
            State=self.request.State,
            City=self.request.City,
            Address=self.request.Address,
            update_count=0,
        )

        with db.transaction():
            db.persist(personal_details)
        return jsonify({"Agent_ID": personal_details.id, "Agent_created": True})



    def update_account(self, acc_id):

        personal_data = Personaldetailsmodels.query.get(acc_id)

        personal_data.FirstName = self.request.FirstName
        personal_data.LastName = self.request.LastName
        personal_data.PhoneNumber = self.request.PhoneNumber
        personal_data.ZipCode = self.request.ZipCode 
        personal_data.State = self.request.State
        personal_data.City = self.request.City
        personal_data.Address = self.request.Address
         

        with db.transaction():

            db.persist(personal_data)

        return {"Status": "ACCOUNT_DETAILS_UPDATED_SUCCESSFULLY"}
