from dataclasses import dataclass
from datetime import datetime
from typing import Dict

from flask import jsonify, Response

from payzark_connect.models.OtpVerificationModel import (
    OtpVerificationStatus,
)
from .. import db
from ..models.PartnerModel import PartnerModel
from ..util.token import generate_token, PartnerInfo


@dataclass
class RegistrationOtpVerificationRequestBody:
    partnerId: int
    otp: str

    def __init__(self, request_dict: Dict):
        for k, v in request_dict.items():
            setattr(self, k, v)


class RegistrationOtpVerificationHandler:
    request: RegistrationOtpVerificationRequestBody

    def __init__(self, request: Dict):
        self.request = RegistrationOtpVerificationRequestBody(request)

    def handle(self):
        existing_partner_candidate = self.__get_partner_candidate()
        if not existing_partner_candidate:
            return jsonify({
                "error": True,
                "message": f"Partner does not exist for"
            }), 404
        elif existing_partner_candidate.registration_verification.status == OtpVerificationStatus.VERIFIED:
            return jsonify({
                "error": True,
                "message": f"Partner already verified"
            }), 403
        elif existing_partner_candidate.registration_verification.otp_expire_at > datetime.utcnow():
            return jsonify({
                "error": True,
                "message": f"Partner entered expired OTP"
            }), 403
        elif existing_partner_candidate.registration_verification.otp != self.request.otp:
            return jsonify({
                "error": True,
                "message": f"Partner entered incorrect OTP"
            }), 400

        existing_partner_candidate.registration_verification.status = OtpVerificationStatus.VERIFIED

        with db.transaction():
            db.persist(existing_partner_candidate)

        resp = Response("")
        resp.headers["access_token"] = generate_token(PartnerInfo(
            partner_id=existing_partner_candidate.id,
            role=existing_partner_candidate.role,
            payzark_tenant_id=existing_partner_candidate.payzark_tenant_id
        ))
        resp.status = 200
        return resp

    def __get_partner_candidate(self) -> PartnerModel | None:
        result = PartnerModel.query.filter(
            PartnerModel.id == self.request.partnerId,
        )
        if result.count() == 0:
            return None

        return result[0]
