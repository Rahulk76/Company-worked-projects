from enum import IntEnum
from sqlalchemy import  Enum
from dataclasses import dataclass
from datetime import datetime
from ..db import db



class AccountType(IntEnum):
    SAVINGS = 1
    CURRENT = 2



@dataclass
class AccountDetailsModel(db.Model):
    __tablename__ = "Account"

    # Dataclass
    id: int
    distributor_name:str
    bank_name: str
    account_number: int    
    ifsc_code: str
    type_of_account: AccountType
    bank_passbook: str
    cancelled_cheque: str
    created_at: datetime
    updated_at: datetime
    update_count: int 

    
    # Entity mapping
    id = db.Column(db.BigInteger, autoincrement=True, primary_key=True)
    distributor_name = db.Column(db.String(), nullable=False)
    bank_name= db.Column(db.String(20), nullable=False)
    account_number= db.Column(db.BigInteger(), nullable=False)
    ifsc_code=db.Column(db.String(11), nullable=False)
    type_of_account=db.Column(Enum(AccountType), nullable=False)
    bank_passbook=db.Column(db.String(100), nullable=False)
    cancelled_cheque=db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    update_count = db.Column(db.Integer, nullable=False)



    __mapper_args__ = {"version_id_col": update_count}



