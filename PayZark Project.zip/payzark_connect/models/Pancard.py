from dataclasses import dataclass
from datetime import datetime
from ..db import db




@dataclass
class PancardModel(db.Model):
    __tablename__ = "Pan_card"


    #Dataclass
    id: int
    distributor_name: str 
    pancard_number: str
    Panfront_image: str
    created_at: datetime
    updated_at: datetime
    update_count: int


    # Entity mapping
    id = db.Column(db.BigInteger, autoincrement=True, primary_key=True)
    distributor_name = db.Column(db.String, nullable=False)
    pancard_number =  db.Column(db.String(10), autoincrement=True)
    Panfront_image = db.Column(db.String, default=None, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    update_count = db.Column(db.Integer, nullable=False)

    __mapper_args__ = {"version_id_col": update_count}