from dataclasses import dataclass
from datetime import datetime
from ..db import db
# from sqlalchemy import Enum,relationship
from enum import IntEnum 

# from payzark_connect.models.OtpVerificationModel import OtpVerificationModel


@dataclass
class Personaldetailsmodels(db.Model):
    __tablename__ = "PersonalApi_details" 


    #Dataclass
    id: int
    FirstName: str
    LastName: str
    PhoneNumber: int
    ZipCode: int    
    State: str
    City: str
    Address: str
    created_at: datetime
    updated_at: datetime
    update_count: int
    # otp_verification_id = int

    # Entity mapping
    id = db.Column(db.BigInteger, autoincrement=True, primary_key=True)
    FirstName = db.Column(db.String(100), nullable=False)
    LastName = db.Column(db.String(100), nullable=False)
    PhoneNumber = db.Column(db.BigInteger, nullable=False)
    ZipCode =  db.Column(db.Integer, nullable=False)
    State = db.Column(db.String(100),nullable=False)
    City = db.Column(db.String(100),nullable=False)       
    Address = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    update_count = db.Column(db.Integer, nullable=False)


# # Relationships
# otp_verification: OtpVerificationModel = relationship(
#     "OtpVerificationModel",


    __mapper_args__ = {"version_id_col": update_count}
