# from sqlalchemy import Enum
from dataclasses import dataclass
from datetime import datetime
from ..db import db
import string

@dataclass
class AadharModel(db.Model):
    __tablename__ = "aadhar"

    # Dataclass
    id: int
    first_name: string
    last_name: string
    phone_number: int
    created_at: datetime
    updated_at: datetime
    update_count: int

    # Entity mapping
    id = db.Column(db.BigInteger, autoincrement=True, primary_key=True)
    first_name = db.Column(db.String(255), nullable=False)
    last_name = db.Column(db.String(255), nullable=False)
    phone_number = db.Column(db.BigInteger, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    update_count = db.Column(db.Integer, nullable=False)

    __mapper_args__ = {"version_id_col": update_count}
