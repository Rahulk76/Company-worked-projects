from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum

from sqlalchemy import Index, Enum

from . import AttachmentModel
from ..db import db


class PartnerIdentificationType(IntEnum):
    PASSPORT = 1
    AADHAR = 2
    PAN = 3
    DL = 4


class PartnerIdentificationStatus(IntEnum):
    PENDING_VERIFICATION = 1
    VERIFIED = 2
    CONFLICT = 3


@dataclass
class PartnerIdentificationModel(db.Model):
    __tablename__ = "partner_identifications"

    # Dataclass
    id: int
    partner_id: int
    identification_type: PartnerIdentificationType
    status: PartnerIdentificationStatus
    attachment: AttachmentModel
    created_at: datetime
    updated_at: datetime
    update_count: int

    # Entity mapping
    id = db.Column(db.BigInteger, autoincrement=True, primary_key=True)
    partner_id = db.Column(
        db.BigInteger, db.ForeignKey("partners.id"), index=True, nullable=False
    )
    identification_type = db.Column(Enum(PartnerIdentificationType), nullable=False)
    status = db.Column(Enum(PartnerIdentificationStatus), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    update_count = db.Column(db.Integer, nullable=False)

    __table_args__ = (
        Index(
            "partner_identifications_by_type_index",
            partner_id,
            identification_type,
        ),
    )

    __mapper_args__ = {"version_id_col": update_count}
