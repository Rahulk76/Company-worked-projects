from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum

from sqlalchemy import Enum

from ..db import db


class OtpVerificationStatus(IntEnum):
    UNVERIFIED = 1
    VERIFIED = 2


@dataclass
class OtpVerificationModel(db.Model):
    __tablename__ = "otp_verifications"

    # Dataclass
    id: int
    otp: int
    otp_expire_at: datetime
    otp_resend_eligible_at: datetime
    status: OtpVerificationStatus
    resend_attempts: int
    ip_address: str
    created_at: datetime
    updated_at: datetime
    update_count: int

    # Entity mapping
    id = db.Column(db.BigInteger, autoincrement=True, primary_key=True)
    otp = db.Column(db.Integer, nullable=False)
    otp_expire_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    otp_resend_eligible_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    status = db.Column(Enum(OtpVerificationStatus), nullable=False)
    resend_attempts = db.Column(db.Integer, nullable=False)
    ip_address = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    update_count = db.Column(db.Integer, nullable=False)

    __mapper_args__ = {"version_id_col": update_count}
