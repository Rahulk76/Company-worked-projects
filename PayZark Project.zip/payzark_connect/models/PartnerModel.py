from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum

from sqlalchemy import Index, Enum
from sqlalchemy.orm import relationship

from payzark_connect.models.OtpVerificationModel import OtpVerificationModel
from ..db import db


class PartnerAccountStatus(IntEnum):
    # Partner could be un-verified or not yet fully onboarded for a tenant
    CREATED = 1

    # Partner is active if all the on-boarding steps are complete for a tenant
    ACTIVE = 2

    # Disables all actions for a partner if suspended
    SUSPENDED = 3


class PartnerRole(IntEnum):
    # A partner is just an agent like and do not have any agents under them
    DEFAULT = 1

    # A partner is like a distributor and has many agents under them
    ELEVATED = 2

    # This is an admin to this app
    ADMIN = 3


@dataclass
class PartnerModel(db.Model):
    __tablename__ = "partners"

    # Dataclass
    id: int
    first_name: str
    last_name: str
    postal_code: int
    phone_country_code: str
    phone_number: int
    payzark_tenant_id: int
    status: PartnerAccountStatus
    role: PartnerRole
    registration_verification_id: int
    login_verification_id: int
    created_at: datetime
    updated_at: datetime
    update_count: int

    # Entity mapping
    id = db.Column(db.BigInteger, autoincrement=True, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    postal_code = db.Column(db.Integer, nullable=False)
    phone_country_code = db.Column(db.String(3), nullable=False)
    phone_number = db.Column(db.BigInteger, nullable=False)
    payzark_tenant_id = db.Column(db.Integer, nullable=False)
    status = db.Column(Enum(PartnerAccountStatus), nullable=False)
    role = db.Column(Enum(PartnerRole), nullable=False)
    registration_verification_id = db.Column(
        db.BigInteger,
        db.ForeignKey(
            "otp_verifications.id",
        ),
    )
    login_verification_id = db.Column(
        db.BigInteger, db.ForeignKey("otp_verifications.id"), nullable=True
    )
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    update_count = db.Column(db.Integer, nullable=False)

    # Relationships
    registration_verification: OtpVerificationModel = relationship(
        "OtpVerificationModel",
        foreign_keys=[registration_verification_id],
        uselist=False,
        lazy="select",
    )
    login_verification: OtpVerificationModel = relationship(
        "OtpVerificationModel",
        foreign_keys=[login_verification_id],
        uselist=False,
        lazy="select",
    )

    __table_args__ = (
        Index(
            "partners_existing_partner_index",
            phone_country_code,
            phone_number,
            payzark_tenant_id,
        ),
    )

    __mapper_args__ = {"version_id_col": update_count}
