from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum

from sqlalchemy import Enum

from ..db import db


class AttachmentSummary(IntEnum):
    NA: 1
    FRONT = 2
    BACK = 3
    FIRST = 4
    LAST = 5


class OwnerType(IntEnum):
    PARTNER = 1


@dataclass
class AttachmentModel(db.Model):
    __tablename__ = "attachments"

    # Dataclass
    id: int
    owner_id: int
    owner_type: OwnerType
    link: str
    summary: AttachmentSummary
    created_at: datetime
    updated_at: datetime
    update_count: int

    # Entity mapping
    id = db.Column(db.BigInteger, autoincrement=True, primary_key=True)
    partner_id = db.Column(
        db.BigInteger, db.ForeignKey("partners.id"), index=True, nullable=False
    )
    link = db.Column(db.String(1000), nullable=False)
    summary = db.Column(Enum(AttachmentSummary), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    update_count = db.Column(db.Integer, nullable=False)

    __mapper_args__ = {"version_id_col": update_count}
