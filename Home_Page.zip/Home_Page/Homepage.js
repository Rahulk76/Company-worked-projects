import React, { useState } from "react";
import "./Homepage.css";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Breadcrumb from "react-bootstrap/Breadcrumb";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";

import Carousel from "react-elastic-carousel";
import "./Homepage.css";

import Mt1 from "../../assets/Mt1.png";
import Mt2 from "../../assets/Mt2.png";
import AEPS from "../../assets/AEPS.png";
import Electricity from "../../assets/Electricity.png";
import Prepaid from "../../assets/Prepaid.png";
import Postpaid from "../../assets/Postpaid.png";
import DTH from "../../assets/DTH.png";
import Gas from "../../assets/Gas.png";
import water from "../../assets/water.png";
import gift from "../../assets/gift.png";
import wallet from "../../assets/wallet.png";
import fund from "../../assets/fund.png";
import reports from "../../assets/reports.png";
// import  Carousel  from '@trendyol-js/react-carousel';
import ReportFirstPage from "../../components/ReportFirstPage";

const breakPoints = [
  { width: 1, itemsToShow: 1 },
  { width: 550, itemsToShow: 2, itemsToScroll: 2 },
  { width: 768, itemsToShow: 3 },
  { width: 1200, itemsToShow: 4, itemsToScroll: 4 },
];


const Reportmainpage = () => {


  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);












  const JsonData = [
    {
      name: "Money  Transfer-1",
      img: Mt1,
      abc: false,
      img1: Mt2,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Money Transfer-2",
      img: Mt2,
      abc: true,
      img1: Mt2,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "AEPS",
      img: AEPS,
      abc: false,
      img1: Mt2,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Electricity",
      img: Electricity,
      fields: [
        {
          field_id: "Electricity",
          field_label: "Select Operator",
          field_mandatory: "yes",
          field_placeholder: "Enter Number",
          field_type: "number",
          field_value: "",
        },
        {
          field_id: "Electricity",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Select your operator",
            },
            {
              option_label: "PowerGrid Corporation of India",
            },
            {
              option_label: "NHPC Limited",
            },
            {
              option_label: "NTPC Limited",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "DTH",
      img: DTH,
      fields: [
        {
          field_id: "DTH",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter Number",
          field_type: "number",
          field_value: "",
        },
        {
          field_id: "DTH",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Select your operator",
            },
            {
              option_label: "Tata Play",
            },
            {
              option_label: "DD Free Dish",
            },
            {
              option_label: "Dish TV d2h Zing Digital",
            },
            {
              option_label: "Airtel digital TV",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Prepaid",
      img: Prepaid,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Gas",
      img: Gas,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Water",
      img: water,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Gift Card",
      img: gift,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Wallet",
      img: wallet,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Postpaid",
      img: Postpaid,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Fund Request",
      img: fund,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
    {
      name: "Reports",
      img: reports,
      fields: [
        {
          field_id: "english_name",
          field_label: "Name",
          field_mandatory: "yes",
          field_placeholder: "Enter name",
          field_type: "text",
          field_value: "",
        },
        {
          field_id: "employment",
          field_label: "Employment desired",
          field_value: "Part-Time",
          field_mandatory: "yes",
          field_options: [
            {
              option_label: "Full-Time",
            },
            {
              option_label: "Part-Time",
            },
          ],
          field_type: "select",
        },
      ],
    },
  ];

  return (
    <div style={{ width: "100%" }}>
      
      <div className="carousel-wrapper" style={{ display: "flex" }}>
        <Carousel breakPoints={breakPoints}>
          {JsonData.map((value, index) => {
            return <ReportFirstPage value={value} />; 
          })}
        </Carousel>
    

          </div> 

        
          <Modal
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={show}
            onHide={handleClose}
          >

           
            <Modal.Header
              closeButton
              style={{ display: "flex", justifyContent: "center" }}
              >
              <Modal.Title
                id="contained-modal-title-vcenter"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
                >
                {/* {value.name} */}
              </Modal.Title>
            </Modal.Header>
                {JsonData.map((value,index)=>{
            <Modal.Body>
              <Breadcrumb className="nav3">
                <Breadcrumb.Item variant="h3" className="nav3">
                  Money Transfer-1
                </Breadcrumb.Item>
                <Breadcrumb.Item className="nav3"> Banking</Breadcrumb.Item>
                <Breadcrumb.Item className="nav3">
                  Money transfer-1
                </Breadcrumb.Item>
              </Breadcrumb>
              <Breadcrumb className="center1">
                <h3>Money Transfer-1</h3>
              </Breadcrumb>

              {value.abc ? (
              <InputGroup className="mb-3">
                <Form.Control
                  placeholder="enter the mobile number"
                  aria-label="enter the mobile number"
                  aria-describedby="basic-addon2"
                />
                <Button variant="primary" id="button-addon2">
                  search
                </Button>
              </InputGroup>): ""}
              {value.abc ? (
                <img
                  src={value.img1}
                  alt=""
                  style={{ width: "50px", height: "100px" }}
                />
              ) : (
                ""
              )}
            </Modal.Body>
             })}
          </Modal>
          
        
      </div>
      
    
  );
};

export default Reportmainpage;
